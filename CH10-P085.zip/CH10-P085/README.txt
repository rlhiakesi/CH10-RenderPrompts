SBL 1.0 resolved page rendering package
Render target: CH10-P085
Entry file: CH10-P085.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Celeste Character Sheet.png
  Assets/Aurelia Character Sheet.png
  Assets/Midori Character Sheet 13C.png
  Assets/High-Priestess-Seraphine’s-Office-Suite.png
  Assets/Midori Character Sheet 13B.png
  Assets/Helena Model Sheet.png
  Assets/Lucia model sheet.png
  Assets/Eliane Character Sheet.png
  Assets/Lucia Expression Sheet.png
  Assets/Roselyn Character Sheet.png
  Assets/Lucia Character Sheet.png
  Assets/Seraphine character sheet.png
  Assets/Midori Character Sheet 13A.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
