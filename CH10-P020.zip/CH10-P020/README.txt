SBL 1.0 resolved page rendering package
Render target: CH10-P020
Entry file: CH10-P020.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Shrine-Maiden-Costume-Production-Sheet.png
  Assets/Lucia model sheet.png
  Assets/Midori Character Sheet 13B.png
  Assets/Temple-of-Light-Evolution-Sheet.png
  Assets/Lucia Character Sheet.png
  Assets/Lucia Expression Sheet.png
  Assets/Midori Character Sheet 13C.png
  Assets/Temple-of-Light-Mature-Exterior.png
  Assets/Midori Character Sheet 13A.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
