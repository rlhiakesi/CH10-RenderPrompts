SBL 1.0 resolved page rendering package
Render target: CH10-P076
Entry file: CH10-P076.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Sherin-Character-Sheet.png
  Assets/Midori Character Sheet 13B.png
  Assets/Temple-Clothing-Evolution-Sheet.png
  Assets/Temple-of-Light-Evolution-Sheet.png
  Assets/Temple-of-Light-Mature-Exterior.png
  Assets/Frenklyn-Character-Sheet.png
  Assets/Midori Character Sheet 13A.png
  Assets/Roselyn Character Sheet.png
  Assets/Midori Character Sheet 13C.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
